package net.matheusSilverio.com;

public class Main {
    public static void main(String[] args) {

        // Sistema para teste basico
        System.out.println("Vamos criar uma ABB com objetos da classe Integer:\n");
        ABB abb1 = new ABB();
        System.out.println("Inserimos " + abb1.inserir(8));
        System.out.println("Inserimos " + abb1.inserir(7));
        System.out.println("Inserimos " + abb1.inserir(9));
        System.out.println("Inserimos " + abb1.inserir(6));
        System.out.println("Inserimos " + abb1.inserir(5));
        System.out.println("Inserimos " + abb1.inserir(6));
        System.out.println(" ");

        // Utilizando preOrdemNaoRecursiva || Ex 4.1
        abb1.preOrdemNaoRecursivo();

        // Achando menor e maior de forma iterativa || Ex 4.2
        System.out.println("menor e maior de forma iterativa: ");
        abb1.getMenorIterativo();
        abb1.getMaiorIterativo();

    }
}