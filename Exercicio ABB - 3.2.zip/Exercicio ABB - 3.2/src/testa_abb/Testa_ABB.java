
package testa_abb;

public class Testa_ABB {

    public static void main(String[] args) {

        System.out.println("\n\nVamos criar uma ABB com objetos da classe Integer:\n");
        ABB abb1 = new ABB();
        abb1.inserir(12);
        abb1.inserir(6);
        abb1.inserir(4);
        abb1.inserir(15);
        abb1.inserir(13);
        abb1.inserir(25);
        abb1.inserir(2);
        abb1.inserir(5);

        System.out.println("\n\nVamos mostrar a ABB percorrendo em-ordem:\n");
        abb1.emOrdem();

        System.out.println("\n\nVamos mostrar a ABB percorrendo pre-ordem:\n");
        abb1.preOrdem();

        System.out.println("\n\nVamos mostrar a ABB percorrendo pos-ordem:\n");
        abb1.posOrdem();

        System.out.println("\n\nVamos mostrar a ABB percorrendo em nivel:\n");
        abb1.emNivel();

        // parte inversa    
        System.out.println("\n\nVamos mostrar a ABB crescente:\n");
        abb1.inversed();
        abb1.readBigger();
    }

}
