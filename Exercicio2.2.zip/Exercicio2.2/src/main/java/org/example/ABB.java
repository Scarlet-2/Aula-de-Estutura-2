package org.example;

// Árvore Binária de Busca
class ABB<E extends Comparable<E>> {

    private Node raiz;

    public ABB() {
        raiz = null;
    }

    public boolean isEmpty() {
        return (raiz == null);
    }

    public E add(E valor) {
        try {
            Node novo = new Node(valor);
            this.add(novo, raiz);
        } catch (Exception erroMemoria) {
            return null;
        } // memória insuficiente
        return (valor);
    }

    private Node add(Node novo, Node anterior) {
        if (raiz == null) {
            raiz = novo;
            return raiz;
        }
        if (anterior != null) {
            if (novo.getValue().compareTo(anterior.getValue()) < 0) {
                // inserir o novo objeto na sub-árvore esquerda
                Node esquerdo = anterior.getFilhoEsquerdo();
                Node proximo = add(novo, esquerdo);
                anterior.setFilhoEsquerdo(proximo);
            } else {
                // inserir o novo objeto na sub-árvore direita
                Node direito = anterior.getFilhoDireito();
                Node proximo = add(novo, direito);
                anterior.setFilhoDireito(proximo);
            }
        } else anterior = novo;
        return anterior;
    }

    public void emOrdem() {
        emOrdem(raiz);
    }

    public void emOrdem(Node no) { // mostra os objetos separados por linhas
        if (no != null) {
            emOrdem(no.getFilhoEsquerdo());
            System.out.print(no.getValue() + "\n");
            emOrdem(no.getFilhoDireito());
        }
    }
}
