package org.example;

public class Main {
    public static void main(String[] args) {
        // Teste de ordem por Nome (FUNCIONAL)
        ABB abb4 = new ABB();
        abb4.add(new Aluno("999-9", "Ana", 'F', 9.5f));
        abb4.add(new Aluno("444-4", "Matheus", 'M', 5.5f));
        abb4.add(new Aluno("111-1", "Luiz", 'M', 6.5f));
        abb4.add(new Aluno("444-4", "Betty", 'F', 9.0f));
        abb4.add(new Aluno("888-8", "Caio", 'M', 5.5f));
        abb4.add(new Aluno("333-3", "Lara", 'F', 7.8f));
        abb4.emOrdem();
    }
}
