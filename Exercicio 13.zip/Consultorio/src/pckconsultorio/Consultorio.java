package pckconsultorio;

import java.util.LinkedList;

public class Consultorio extends javax.swing.JFrame {
    
    LinkedList<Paciente> listaPacientes = new LinkedList<Paciente>();
    AVL arvorePaciente = new AVL();

    public Consultorio() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        filaespera = new javax.swing.JButton();
        chamar1 = new javax.swing.JButton();
        registrarfila = new javax.swing.JButton();
        filaespera1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Consultório");

        jLabel1.setText("Nome do paciente: ");

        jLabel2.setText("RG do paciente: ");

        filaespera.setFont(new java.awt.Font("Calibri", 1, 16)); // NOI18N
        filaespera.setText("Ver a fila de espera");
        filaespera.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                filaesperaActionPerformed(evt);
            }
        });

        chamar1.setFont(new java.awt.Font("Calibri", 1, 16)); // NOI18N
        chamar1.setText("<html>&nbsp;&nbsp;&nbsp;Chamar <br>consultório</html>");
        chamar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chamar1ActionPerformed(evt);
            }
        });

        registrarfila.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        registrarfila.setText("Registrar");
        registrarfila.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registrarfilaActionPerformed(evt);
            }
        });

        filaespera1.setFont(new java.awt.Font("Calibri", 1, 16)); // NOI18N
        filaespera1.setText("<html>Pacientes em espera<br/>em ordem alfabética</html>");
        filaespera1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                filaespera1ActionPerformed(evt);
            }
        });

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jTextField1, javax.swing.GroupLayout.DEFAULT_SIZE, 117, Short.MAX_VALUE)
                            .addComponent(jTextField2))
                        .addGap(33, 33, 33)
                        .addComponent(registrarfila)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(filaespera, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(filaespera1, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(356, 356, 356))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(chamar1, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(62, 62, 62)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 292, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(42, 42, 42)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(44, 44, 44)
                        .addComponent(registrarfila, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(48, 48, 48)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(filaespera, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(filaespera1, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, Short.MAX_VALUE)
                        .addComponent(chamar1, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(66, 66, 66))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        setSize(new java.awt.Dimension(691, 459));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    // REGISTRAR
    private void registrarfilaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_registrarfilaActionPerformed
        // Registra (FEITO)
        limpaAdiciona();
    }//GEN-LAST:event_registrarfilaActionPerformed

    // FILA DE ESPERA
    private void filaesperaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_filaesperaActionPerformed
        // VER FILA DE ESPERA (FEITO)
        String resp = "";
        for(int i = 0; i < listaPacientes.size(); i++) {
            System.out.println(listaPacientes.get(i));
            resp += listaPacientes.get(i) + "\n";
        }
        jTextArea1.setText("== Lista de chegada de Pacientes ==");
        jTextArea1.setText(resp);
    }//GEN-LAST:event_filaesperaActionPerformed

    // FILA DE ESPERA ORDEM ALFABETICA
    private void filaespera1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_filaespera1ActionPerformed
        // FILA DE ESPERA ORDEM ALFABETICA (FEITO)
        System.out.println("");
        System.out.println(arvorePaciente.emOrdem());
        jTextArea1.setText("== Lista de AVL de Pacientes em Ordem Alfabetica ==");
        jTextArea1.setText(arvorePaciente.emOrdem());
    }//GEN-LAST:event_filaespera1ActionPerformed

    // CHAMAR PARA O CONSULTORIO
    private void chamar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chamar1ActionPerformed
        // CHAMAR PARA O CONSULTORIO (TERMINAR!)
        // TODO
        System.out.println(listaPacientes.pop());
    }//GEN-LAST:event_chamar1ActionPerformed

    void limpaAdiciona() {
        // Pega Texto
        String nomepaciente = jTextField1.getText();
        String rgPaciente = jTextField2.getText();
        
        // Adiciona Paciente para lista Linkada e AVL
        listaPacientes.add(new Paciente(nomepaciente, rgPaciente));
        arvorePaciente.insereAVL(new Paciente(nomepaciente, rgPaciente));
        
        // Sistema de debug
        // System.out.println("Paciente Inserido na AVL: " + arvorePaciente.emNivelString());
        
        // Limpa os campos 
        jTextField1.setText("");
        jTextField2.setText("");
    }
    
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Consultorio().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton chamar1;
    private javax.swing.JButton filaespera;
    private javax.swing.JButton filaespera1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JButton registrarfila;
    // End of variables declaration//GEN-END:variables
}
