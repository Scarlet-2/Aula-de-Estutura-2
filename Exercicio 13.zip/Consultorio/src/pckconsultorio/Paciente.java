package pckconsultorio;

public class Paciente implements Comparable {
   private String rg;
   private String nome;

    public Paciente() {
        this.rg = "";
        this.nome = "";
    }

    public Paciente(String nome, String rg) {
        this.nome = nome;
        this.rg = rg;
    }

    @Override
    public String toString() {
        return this.getNome() + " - RG: " + this.getRg();
    }
    
    public String getRg() {
        return rg;
    }

    public void setRgm(String rg) {
        this.rg = rg;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    @Override
    public int compareTo(Object outro) {
        return this.nome.compareTo(((Paciente)outro).getNome());
    }
}
