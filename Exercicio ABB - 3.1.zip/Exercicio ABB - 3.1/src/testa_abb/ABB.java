
package testa_abb;

import java.util.ArrayList;
import java.util.LinkedList;

class ABB<E extends Comparable<E>> { // Árvore Binária de Busca

    private float soma = 0.0f;
    private int qtde = 0;
    private Node raiz;

    public float mediaMulheresDaTurma() {
        mediaMulheresDaTurma(raiz);
        float media = soma / qtde;
        return media;
    }

    public void mediaMulheresDaTurma(Node node) {
        if (node != null) {
            mediaMulheresDaTurma(node.getFilhoEsquerdo());

            Aluno aluno = (Aluno) node.getValue();
            if (aluno.getSexo() == 'F') {
                System.out.println(aluno.toString());
                soma += aluno.getMedia();
                qtde++;
            }
            mediaMulheresDaTurma(node.getFilhoDireito());
        }
    }

    public ABB() {
        raiz = null;
    }

    public boolean isEmpty() {
        return (raiz == null);
    }

    // Configura a raiz da árvore
    public void setRaiz(Node araiz) {
        raiz = araiz;
    }

    public Node getRaiz() {
        return raiz;
    }

    public E inserir(E valor) {
        try {
            Node novo = new Node(valor);
            this.inserir(novo, raiz);
        } catch (Exception exMemoria) {
            return null;
        } // memória insuficiente
        return (valor);
    }

    private Node inserir(Node novo, Node anterior) {
        if (raiz == null) {
            raiz = novo;
            return raiz;
        }
        if (anterior == null) {
            return novo;
        } else {
            if (novo.getValue().compareTo(anterior.getValue()) < 0) {
                anterior.setFilhoEsquerdo(inserir(novo, anterior.getFilhoEsquerdo()));
            } else {
                anterior.setFilhoDireito(inserir(novo, anterior.getFilhoDireito()));
            }
            return anterior;
        }
    }

    public void emOrdem() {
        emOrdem(raiz);
    }

    public void emOrdem2() {
        emOrdem2(raiz);
    }

    public void preOrdem() {
        preOrdem(raiz);
    }

    public void posOrdem() {
        posOrdem(raiz);
    }

    public void emOrdem(Node no) {
        if (no != null) {
            emOrdem(no.getFilhoEsquerdo());
            System.out.print(no.getValue() + "   ");
            emOrdem(no.getFilhoDireito());
        }
    }

    public void emOrdem2(Node no) {
        if (no != null) {
            emOrdem2(no.getFilhoEsquerdo());
            System.out.print(no.getValue() + "\n");
            emOrdem2(no.getFilhoDireito());
        }
    }

    public void preOrdem(Node no) {
        if (no != null) {
            System.out.print(no.getValue() + "   ");
            preOrdem(no.getFilhoEsquerdo());
            preOrdem(no.getFilhoDireito());
        }
    }

    public void posOrdem(Node no) {
        if (no != null) {
            posOrdem(no.getFilhoEsquerdo());
            posOrdem(no.getFilhoDireito());
            System.out.print(no.getValue() + "   ");
        }
    }

    public void emNivel() {
        Node noAux;
        LinkedList fila = new LinkedList();
        fila.addLast(raiz);
        while (!fila.isEmpty()) {
            noAux = (Node) fila.removeFirst();
            if (noAux.getFilhoEsquerdo() != null) {
                fila.addLast(noAux.getFilhoEsquerdo());
            }
            if (noAux.getFilhoDireito() != null) {
                fila.addLast(noAux.getFilhoDireito());
            }
            System.out.print(noAux.getValue() + "   ");
        }
    }

    public Node getMenor(Node node) {
        if (isEmpty()) {
            return null;
        }
        if (node.getFilhoEsquerdo() == null) {
            return node;
        } else {
            return getMenor(node.getFilhoEsquerdo());
        }
    }

    // Determina o maior elemento a partir de um nó
    public Node getMaior(Node node) {
        if (isEmpty()) {
            return null;
        }
        if (node.getFilhoDireito() == null) {
            return node;
        } else {
            return getMaior(node.getFilhoDireito());
        }
    }

    public Node getMax(Node raiz, Node paiRaiz) {
        if (isEmpty()) {
            return null;
        }
        Node aux;
        if (raiz.getFilhoDireito() == null) {
            aux = raiz;
            if (paiRaiz != null) {
                if (paiRaiz.getFilhoEsquerdo() == raiz) {
                    paiRaiz.setFilhoEsquerdo(raiz.getFilhoEsquerdo());
                } else {
                    paiRaiz.setFilhoDireito(raiz.getFilhoEsquerdo());
                }
            }
            return aux;
        } else {
            return getMax(raiz.getFilhoDireito(), raiz);
        }
    }

    private int compara(Object ob1, Object ob2) {
        return ((Comparable) ob1).compareTo(((Comparable) ob2));
    }

    public boolean eliminar(Object e) {
        return eliminar(raiz, null, e);
    }

    private boolean eliminar(Node node, Node paiRaiz, Object e) {
        Node aux;
        if (node == null) {
            return false;
        } else {
            if (compara(e, node.getValue()) == 0) {
                aux = node;
                if (node.getFilhoEsquerdo() == null && node.getFilhoDireito() == null) {
                    if (paiRaiz == null) {
                        setRaiz(null);
                    } else {
                        if (paiRaiz.getFilhoEsquerdo() != null
                                && compara(paiRaiz.getFilhoEsquerdo().getValue(), e) == 0) {
                            paiRaiz.setFilhoEsquerdo(null);
                        } else if (paiRaiz.getFilhoDireito() != null
                                && compara(paiRaiz.getFilhoDireito().getValue(), e) == 0) {
                            paiRaiz.setFilhoDireito(null);
                        }
                    }
                } else if (node.getFilhoDireito() == null) {
                    if (paiRaiz != null) {
                        if (paiRaiz.getFilhoEsquerdo() != null
                                && compara(paiRaiz.getFilhoEsquerdo().getValue(), e) == 0) {
                            paiRaiz.setFilhoEsquerdo(node.getFilhoEsquerdo());
                        } else {
                            paiRaiz.setFilhoDireito(node.getFilhoEsquerdo());
                        }
                    } else {
                        node.setValue(node.getFilhoEsquerdo().getValue());
                        raiz = raiz.getFilhoEsquerdo();

                    }
                } else if (node.getFilhoEsquerdo() == null) {
                    if (paiRaiz != null) {
                        if (paiRaiz.getFilhoEsquerdo() != null
                                && compara(paiRaiz.getFilhoEsquerdo().getValue(), e) == 0) {
                            paiRaiz.setFilhoEsquerdo(node.getFilhoDireito());
                        } else {
                            paiRaiz.setFilhoDireito(node.getFilhoDireito());
                        }
                    } else {
                        node.setValue(node.getFilhoDireito().getValue());
                        raiz = raiz.getFilhoDireito();

                    }
                } else {
                    aux = getMax(node.getFilhoEsquerdo(), node);
                    node.setValue(aux.getValue());
                }
                aux = null;
                return true;
            } else {
                if (compara(e, node.getValue()) < 0) {
                    return eliminar(node.getFilhoEsquerdo(), node, e);
                } else { // senão, procurar à direita:
                    return eliminar(node.getFilhoDireito(), node, e);
                }
            }
        }
    }

    public Node searchABB(Object obj) {
        return searchABB(raiz, obj);
    }

    private Node searchABB(Node node, Object obj) {
        if (node == null) {
            return null;
        } else {
            if (((Comparable) obj).compareTo(node.getValue()) == 0) {
                return node;
            } else {

                if (((Comparable) obj).compareTo(node.getValue()) < 0) {
                    return searchABB(node.getFilhoEsquerdo(), obj);
                } else {
                    return searchABB(node.getFilhoDireito(), obj);
                }
            }
        }
    }

    public Node find(Object obj) { // método (iterativo) para buscar um obj na ABB
        if (isEmpty())
            return null;
        Node atual = raiz; // começamos na raiz
        while (compara(obj, atual.getValue()) != 0) { // enquanto não encontremos o item procurado
            if (compara(obj, atual.getValue()) < 0) {
                atual = atual.getFilhoEsquerdo();
            } else {
                atual = atual.getFilhoDireito();
            }
            if (atual == null) {
                return null; // retornamos null se não encontramos o item procurado
            }
        }
        return atual; // retornamos o nodo encontrado
    }

    public E insert(E valor) { // implementação iterativa da inserção na ABB
        Node novoNodo;
        try {
            novoNodo = new Node(valor);
        } catch (Exception ex) {
            return null;
        } // memória insuficiente
        if (isEmpty()) {
            raiz = novoNodo; // se a ABB estiver vazia, inserimos na raiz
        } else {
            Node atual = raiz; // começamos procurar pela raiz
            Node pai;
            while (true) { // ciclo que só será interrompido ao acontecer a inserção (break interno)
                pai = atual;
                if (compara(valor, atual.getValue()) < 0) { // verificamos se devemos ir para a esquerda
                    atual = atual.getFilhoEsquerdo();
                    if (atual == null) { // inserir à esquerda
                        pai.setFilhoEsquerdo(novoNodo);
                        break;
                    }
                } else { // ou ir para direita
                    atual = atual.getFilhoDireito();
                    if (atual == null) { // inserir a direita
                        pai.setFilhoDireito(novoNodo);
                        break;
                    }
                }
            }
        }
        return valor;
    }

}
