package testa_abb;

public class Testa_ABB {

    public static void main(String[] args) {
        System.out.println(" ");

        ABB abb2 = new ABB();
        abb2.inserir(new Aluno("888-8", "Caio", 'M', 6.5f));
        abb2.inserir(new Aluno("333-3", "Lara", 'F', 4.5f));
        abb2.inserir(new Aluno("999-9", "Ana", 'M', 9.5f));
        abb2.inserir(new Aluno("444-4", "Betty", 'F', 9.0f));
        abb2.inserir(new Aluno("777-7", "Renata", 'F', 7.2f));

        System.out.println("A media das mulheres da turma é: " + abb2.mediaMulheresDaTurma() + "\n");
    }
}
