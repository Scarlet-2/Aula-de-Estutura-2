package org.example;

import java.util.LinkedList;

// Árvore Binária de Busca
class ABB<E extends Comparable<E>> {

    private Node raiz;

    public ABB() {
        raiz = null;
    }

    public boolean isEmpty() {
        return (raiz == null);
    }

    public E add(E valor) {
        try {
            Node novo = new Node(valor);
            this.add(novo, raiz);
        } catch (Exception erroMemoria) {
            return null;
        } // memória insuficiente
        return (valor);
    }

    private Node add(Node novo, Node anterior) {
        if (raiz == null) {
            raiz = novo;
            return raiz;
        }
        if (anterior != null) {
            if (novo.getValue().compareTo(anterior.getValue()) < 0) {
                // inserir o novo objeto na sub-árvore esquerda
                Node esquerdo = anterior.getFilhoEsquerdo();
                Node proximo = add(novo, esquerdo);
                anterior.setFilhoEsquerdo(proximo);
            } else {
                // inserir o novo objeto na sub-árvore direita
                Node direito = anterior.getFilhoDireito();
                Node proximo = add(novo, direito);
                anterior.setFilhoDireito(proximo);
            }
        } else anterior = novo;
        return anterior;
    }

    public void preOrdem() {
        preOrdem(raiz);
    }

    public void preOrdem(Node no) { // mostra os objetos separados por linhas
        if (no != null) {
            System.out.print(no.getValue() + "\n");
            emOrdem(no.getFilhoEsquerdo());
            emOrdem(no.getFilhoDireito());
        }
    }

    public void posOrdem() {
        posOrdem(raiz);
    }

    public void posOrdem(Node no) {
        if (no != null) {
            emOrdem(no.getFilhoEsquerdo());
            emOrdem(no.getFilhoDireito());
            System.out.print(no.getValue() + "\n");
        }
    }

    public void emOrdem() {
        emOrdem(raiz);
    }

    public void emOrdem(Node no) {
        if (no != null) {
            emOrdem(no.getFilhoEsquerdo());
            System.out.print(no.getValue() + "\n");
            emOrdem(no.getFilhoDireito());
        }
    }

    public void emNivel() {
        Node noAux;
        LinkedList fila = new LinkedList();
        fila.addLast(raiz);
        while (!fila.isEmpty()) {
            noAux = (Node) fila.removeFirst();
            if (noAux.getFilhoEsquerdo() != null) fila.addLast(noAux.getFilhoEsquerdo());
            if (noAux.getFilhoDireito() != null) fila.addLast(noAux.getFilhoDireito());
            System.out.print(noAux.getValue() + "\n");
        }
    }
}
