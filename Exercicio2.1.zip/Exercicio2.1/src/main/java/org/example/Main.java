package org.example;

public class Main {
    public static void main(String[] args) {

        ABB abb = new ABB();
        abb.add(new Integer(6));
        abb.add(new Integer(10));
        abb.add(new Integer(12));
        abb.add(new Integer(11));
        abb.add(new Integer(2));

        System.out.println("PRE ORDEM");
        abb.preOrdem();
        System.out.println(" ");

        System.out.println("EM ORDEM");
        abb.emOrdem();
        System.out.println(" ");

        System.out.println("POS ORDEM");
        abb.posOrdem();
        System.out.println(" ");

        System.out.println("EM NIVEL");
        abb.emNivel();

    }
}
