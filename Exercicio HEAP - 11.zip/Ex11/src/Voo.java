
public class Voo implements Comparable<Voo> {
    private String numeroVoo;
    private String origem;
    private String destino;
    private int horasVoo;
    private String aeronave;
    private int volumeCombustivel;

    // Construtor
    public Voo(String numeroVoo, String origem, String destino, int horasVoo, String aeronave, int volumeCombustivel) {
        this.numeroVoo = numeroVoo;
        this.origem = origem;
        this.destino = destino;
        this.horasVoo = horasVoo;
        this.aeronave = aeronave;
        this.volumeCombustivel = volumeCombustivel;
    }

    // Métodos get/set
    public String getNumeroVoo() { return numeroVoo; }
    public void setNumeroVoo(String numeroVoo) { this.numeroVoo = numeroVoo; }

    public String getOrigem() { return origem; }
    public void setOrigem(String origem) { this.origem = origem; }

    public String getDestino() { return destino; }
    public void setDestino(String destino) { this.destino = destino; }

    public int getHorasVoo() { return horasVoo; }
    public void setHorasVoo(int horasVoo) { this.horasVoo = horasVoo; }

    public String getAeronave() { return aeronave; }
    public void setAeronave(String aeronave) { this.aeronave = aeronave; }

    public int getVolumeCombustivel() { return volumeCombustivel; }
    public void setVolumeCombustivel(int volumeCombustivel) { this.volumeCombustivel = volumeCombustivel; }

    @Override
    public String toString() {
        return "Voo{" +
                "numeroVoo='" + numeroVoo + '\'' +
                ", origem='" + origem + '\'' +
                ", destino='" + destino + '\'' +
                ", horasVoo=" + horasVoo +
                ", aeronave='" + aeronave + '\'' +
                ", volumeCombustivel=" + volumeCombustivel +
                '}';
    }

    @Override
    public int compareTo(Voo outroVoo) {
        return Integer.compare(this.volumeCombustivel, outroVoo.getVolumeCombustivel());
    }
}
