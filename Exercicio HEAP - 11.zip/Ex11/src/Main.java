import java.util.PriorityQueue;

public class Main {
    public static void main(String[] args) {
        int i=1;
        PriorityQueue<Voo> filaDeVoo = new PriorityQueue<>();

        filaDeVoo.add(new Voo("G3 7235", "Curitiba", "Salvador", 2, "Airbus 340", 1000));
        filaDeVoo.add(new Voo("JJ 5463", "Brasília", "São Paulo", 1, "Boeing 767", 500));
        filaDeVoo.add(new Voo("LL 6571", "Fortaleza", "Recife", 1, "Boeing 737", 300));
        filaDeVoo.add(new Voo("DD 7871", "São Paulo", "Rio de Janeiro", 2, "Embraer 195", 800));

        System.out.println("Ordem de pouso por prioridade (menor volume de combustível primeiro): ");

        while (!filaDeVoo.isEmpty()) {
            Voo proximoVoo = filaDeVoo.poll();
            System.out.println(i + "°: " + proximoVoo);
            i++;
        }
    }
}
