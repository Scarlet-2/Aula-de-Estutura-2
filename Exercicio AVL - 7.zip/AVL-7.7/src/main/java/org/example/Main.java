package org.example;

public class Main {
    public static void main(String[] args) {
        AVL avl = new AVL();

        System.out.println("Inserimos: 20, 15, 18, 29, 26, 27, 14");
        avl.insereAVL("20");
        avl.insereAVL("15");
        avl.insereAVL("18");
        avl.insereAVL("29");
        avl.insereAVL("26");
        avl.insereAVL("27");
        avl.insereAVL("14");

        System.out.println("Atravessamento em ordem:");
        System.out.println(avl.emOrdem());
        System.out.println("Atravessamento em n�vel:");
        avl.emNivel();
        System.out.println("Lista Ordenada -1: ");
        avl.minusOneNode();

        System.out.println("\n");

    }

}